package Task2;

public class Account {
    private double balance;

    
    public Account() {
        this.balance = 0.0;
    }

    
    public Account(double balance) {
        this.balance = balance;
    }

    
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    
    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: " + amount);
        } else {
            System.out.println("Invalid withdraw amount or insufficient funds.");
        }
    }

   
    public void displayBalance() {
        System.out.println("Current Balance: " + balance);
    }

   
    public static void main(String[] args) {
        Account account1 = new Account();
        Account account2 = new Account(100.0);

        
        account1.deposit(50);
        account2.deposit(150);

       
        account1.withdraw(30);
        account2.withdraw(70);

        
        account1.displayBalance();
        account2.displayBalance();
    }
}
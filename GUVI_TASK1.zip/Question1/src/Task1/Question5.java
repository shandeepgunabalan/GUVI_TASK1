package Task1;
import java.util.Scanner;

public class Question5 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter a Amount a: ");
		int a=scan.nextInt();
		System.out.println("Enter a Amount b: ");
		int b=scan.nextInt();
		System.out.println("Enter a Amount c: ");
		int c=scan.nextInt();
		if(a<500)
		{
			System.out.println("No Discount is applied: ");
		}
		else if(b>=500 && b<=1000) {
			System.out.println("a 10% Discount is applied: ");
			
		}
		else {
             System.out.println("a 20% Discount is applied: ");
		}

	}

}

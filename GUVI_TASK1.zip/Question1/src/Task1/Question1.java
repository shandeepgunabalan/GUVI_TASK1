package Task1;
public class Question1 {
    public static void main(String[] args) {
    	for(int i=10;i<=50;i++)
    	{
    		System.out.println(i);
    	}
    }
    }
          
          



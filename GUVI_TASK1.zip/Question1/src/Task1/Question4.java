package Task1;

import java.util.Arrays;

public class Question4 {

	public static void main(String[] args) {
		int i,Smallest,n;
		int arr[]= {55,16,44};
		n=arr.length;
		Smallest = arr[0];
		for(i=0;i<n;i++)
		{
			if (arr[i]<Smallest)
			{
				Smallest=arr[i];
			}
		}
		System.out.println("Smallest Element of the array: "+Smallest);
		
	}

}
